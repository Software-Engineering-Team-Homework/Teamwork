package APP;

import APP.domain.User;
import APP.ui.LoginIFrame;

import java.util.ArrayList;

public class App {
    public static void main(String[] args) {


        new LoginIFrame();
    }
}
